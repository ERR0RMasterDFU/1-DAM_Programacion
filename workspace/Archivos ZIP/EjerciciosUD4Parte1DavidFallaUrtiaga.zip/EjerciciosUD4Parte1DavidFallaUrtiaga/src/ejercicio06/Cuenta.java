package ejercicio06;

public abstract class Cuenta {

	public abstract double ingresarDinero (double dinero);
	
	public abstract double sacarDinero (double dinero);
	
	
	
	
	
	
	
}
