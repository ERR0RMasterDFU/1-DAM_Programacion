package ejercicio02;

public class Carta extends Documento {

	
	public Carta(String nombreEmpresa, String direccionEmpresa, String numeroTelefono, String correo) {
		super(nombreEmpresa, direccionEmpresa, numeroTelefono, correo);
		// TODO Auto-generated constructor stub
	}

	private String fecha;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
