package ejercicio02;

public class Tarjeta extends Documento {

	public Tarjeta(String nombreEmpresa, String direccionEmpresa, String numeroTelefono, String correo) {
		super(nombreEmpresa, direccionEmpresa, numeroTelefono, correo);
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
