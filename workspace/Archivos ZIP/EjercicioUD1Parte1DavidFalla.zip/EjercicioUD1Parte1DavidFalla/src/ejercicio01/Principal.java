package ejercicio01;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1=3, num2=5, num3=9;
		int resultado=0;
		int resultado2=0;
		
		System.out.println("¡Bienvenido al ejercicio 1 de la Unidad 1!");
		
		System.out.println();
		
		resultado=num1+num2+num3;
		
		resultado2=resultado-1;
		
		System.out.println("El resultado final es: "+resultado2);
		
	}

}
