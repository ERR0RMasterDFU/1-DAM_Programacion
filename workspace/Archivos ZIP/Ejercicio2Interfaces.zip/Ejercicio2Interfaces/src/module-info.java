/**
 * 
 */
/**
 * 
 */
module Ejercicio2Interfaces {
}