package ejercicio04;

import java.util.Random;
import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);	
		Random rnd= new Random (System.nanoTime());
		
		String aux;
		int tam=10, opcion=0, desde=1, hasta=99; 

		int [] numerosRandom ;
		numerosRandom =new int[tam];
		
		/*4. Rellenar un array unidimensional de 10 posiciones con números aleatorios entre 1 y 99 y 
		mostrar el número guardado en un lugar que indique el usuario por teclado. También se debe 
		mostrar la suma de todos y la media.*/
		
		//INCOMPLETO
		
		System.out.println("------------------------------------------------------------------------------------------------------------------");
		System.out.println("¡Bienvenido al programa que rellena un array unidimensional de 10 posiciones con números aleatorios entre 1 y 99!");
		System.out.println("------------------------------------------------------------------------------------------------------------------");
		
		do {
		
			System.out.println("--------------------------------------");
			System.out.println("1. INICIAR EL PROGRAMA");
			System.out.println("0. SALIR DEL PROGRAMA");
			System.out.println("--------------------------------------");
			
			aux=sc.nextLine();
			opcion=Integer.parseInt(aux);
			
			switch(opcion) {
			
				case 1:
				
					for (int i = 0; i < numerosRandom.length; i++) {
						numerosRandom [i]= rnd.nextInt(hasta-desde+1)+desde;
					}
					
					for (int i = 0; i < numerosRandom.length; i++) {
						
					}
					System.out.println("Por favor, seleccione una posición para ver el número guardado en su interior.");
						aux=sc.nextLine();
						i=Integer.parseInt(aux)-1;
						
						System.out.println("El numero de la posición seleccionada es "+numerosRandom+".");
					}
					break;
			
				case 0:
					break;
			
				default:
					System.out.println("Lo sentimos, no existe ninguna tecla asignada a esa opción. Por favor, elija otra.");
					break;
			
			}
		
		}while(opcion!=0);

		System.out.println("------------------------------------------------------------------------------------------------------------------");
		System.out.println("¡Muchas gracias por usar nuestro programa! y... Disfrute de su cuarto array >:).");
		System.out.println("------------------------------------------------------------------------------------------------------------------");		
	
	}
}