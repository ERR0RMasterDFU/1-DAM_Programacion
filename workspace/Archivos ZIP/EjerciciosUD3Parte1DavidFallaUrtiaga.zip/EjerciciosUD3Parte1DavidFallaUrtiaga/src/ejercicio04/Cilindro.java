package ejercicio04;

public class Cilindro {

	
	public double calcularVolumenCilindro (double radio, double altura) {
		int dos=2;
		double VolumenCil=0;
		
		VolumenCil=Math.PI*Math.pow(radio, dos)*altura;
		
		return VolumenCil;
	}
	
}
