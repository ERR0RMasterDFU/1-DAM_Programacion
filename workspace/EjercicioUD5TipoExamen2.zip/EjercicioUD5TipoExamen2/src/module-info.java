/**
 * 
 */
/**
 * 
 */
module EjercicioUD5TipoExamen2 {
}